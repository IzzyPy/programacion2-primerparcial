package com.tuapp.dao;
import androidx.room.*;
import com.tuapp.entity.Categoria;
import java.util.List;
@Dao
public interface CategoriaDao {
    @Insert
    long insertar(Categoria categoria);

    @Update
    void actualizar(Categoria categoria);

    @Delete
    void eliminar(Categoria categoria);

    @Query("SELECT * FROM categorias WHERE usuarioId = :usuarioId")
    List<Categoria> obtenerPorUsuario(int usuarioId);
}
