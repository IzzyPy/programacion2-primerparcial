package com.tuapp.dao;


import androidx.room.*;
import com.tuapp.entity.Cuenta;
import java.util.List;

@Dao
public interface CuentaDao {
    @Insert
    long insertar(Cuenta cuenta);

    @Update
    void actualizar(Cuenta cuenta);

    @Delete
    void eliminar(Cuenta cuenta);

    @Query("SELECT * FROM cuentas WHERE usuarioId = :usuarioId")
    List<Cuenta> obtenerPorUsuario(int usuarioId);

    @Query("SELECT * FROM cuentas WHERE id = :id")
    Cuenta obtenerPorId(int id);
}