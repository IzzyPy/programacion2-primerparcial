package com.tuapp.ui.adapter.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.tuapp.data.AppDatabase;
import com.tuapp.entity.Cuenta;
import com.tuapp.moneywise.databinding.FragmentCuentasBinding;
import com.tuapp.ui.adapter.CuentaAdapter;
import java.util.ArrayList;
import java.util.List;

public class CuentasFragment extends Fragment {

    private FragmentCuentasBinding binding;
    private AppDatabase db;
    private CuentaAdapter adapter;
    private int usuarioId = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentCuentasBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = AppDatabase.getInstance(requireContext());

        configurarRecyclerView();
        cargarCuentas();

        binding.fabAgregarCuenta.setOnClickListener(v -> mostrarDialogoAgregar());
    }

    private void configurarRecyclerView() {
        binding.recyclerViewCuentas.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new CuentaAdapter(new ArrayList<>(), cuenta -> {
            // Navegar a detalles o editar
        });
        binding.recyclerViewCuentas.setAdapter(adapter);
    }

    private void cargarCuentas() {
        new Thread(() -> {
            List<Cuenta> cuentas = db.cuentaDao().obtenerPorUsuario(usuarioId);

            // Verificar si el Fragment aún está activo antes de actualizar UI
            if (getActivity() != null && isAdded()) {
                getActivity().runOnUiThread(() -> {
                    if (adapter != null && binding != null) {
                        adapter.actualizarLista(cuentas);
                    }
                });
            }
        }).start();
    }

    private void mostrarDialogoAgregar() {
        // Implementar diálogo para agregar cuenta
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}