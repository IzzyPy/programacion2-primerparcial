package com.tuapp.data;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import android.content.Context;

import com.tuapp.dao.UsuarioDao;
import com.tuapp.dao.PresupuestoDao;
import com.tuapp.dao.CuentaDao;
import com.tuapp.dao.TransaccionDao;
import com.tuapp.dao.CategoriaDao;
import com.tuapp.entity.Usuario;
import com.tuapp.entity.Presupuesto;
import com.tuapp.entity.Cuenta;
import com.tuapp.entity.Transaccion;
import com.tuapp.entity.Categoria;

@Database(
        entities = {
                Usuario.class,
                Presupuesto.class,
                Cuenta.class,
                Transaccion.class,
                Categoria.class
        },
        version = 1,
        exportSchema = false
)
@TypeConverters({Converters.class})  // AGREGAR ESTA LÍNEA
public abstract class AppDatabase extends RoomDatabase {

    public abstract UsuarioDao usuarioDao();
    public abstract PresupuestoDao presupuestoDao();
    public abstract CuentaDao cuentaDao();
    public abstract TransaccionDao transaccionDao();
    public abstract CategoriaDao categoriaDao();

    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "moneywise_database"
                    ).build();
                }
            }
        }
        return INSTANCE;
    }
}