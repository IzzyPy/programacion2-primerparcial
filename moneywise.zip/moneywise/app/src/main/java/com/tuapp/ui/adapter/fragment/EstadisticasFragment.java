package com.tuapp.ui.adapter.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.tuapp.data.AppDatabase;
import com.tuapp.moneywise.databinding.FragmentEstadisticasBinding;

public class EstadisticasFragment extends Fragment {

    private FragmentEstadisticasBinding binding;
    private AppDatabase db;
    private int usuarioId = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentEstadisticasBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = AppDatabase.getInstance(requireContext());

        cargarEstadisticas();
    }

    private void cargarEstadisticas() {
        new Thread(() -> {
            double totalIngresos = db.transaccionDao().obtenerTotalIngresos(usuarioId);
            double totalGastos = db.transaccionDao().obtenerTotalGastos(usuarioId);
            double balance = totalIngresos - totalGastos;

            if (getActivity() != null && isAdded()) {
                getActivity().runOnUiThread(() -> {
                    if (binding != null) {
                        binding.textViewIngresos.setText(String.format("$%.2f", totalIngresos));
                        binding.textViewGastos.setText(String.format("$%.2f", totalGastos));
                        binding.textViewBalance.setText(String.format("$%.2f", balance));
                    }
                });
            }
        }).start();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}