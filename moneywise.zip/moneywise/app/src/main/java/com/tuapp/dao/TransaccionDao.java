package com.tuapp.dao;

import androidx.room.*;
import com.tuapp.entity.Transaccion;
import java.util.List;

@Dao
public interface TransaccionDao {
    @Insert
    long insertar(Transaccion transaccion);

    @Update
    void actualizar(Transaccion transaccion);

    @Delete
    void eliminar(Transaccion transaccion);

    @Query("SELECT * FROM transacciones WHERE cuentaId = :cuentaId ORDER BY fecha DESC")
    List<Transaccion> obtenerPorCuenta(int cuentaId);

    @Query("SELECT * FROM transacciones WHERE id = :id")
    Transaccion obtenerPorId(int id);

    // Métodos nuevos que faltan:

    @Query("SELECT * FROM transacciones WHERE usuarioId = :usuarioId ORDER BY fecha DESC")
    List<Transaccion> obtenerPorUsuario(int usuarioId);

    @Query("SELECT COALESCE(SUM(monto), 0) FROM transacciones WHERE usuarioId = :usuarioId AND tipo = 'INGRESO'")
    double obtenerTotalIngresos(int usuarioId);

    @Query("SELECT COALESCE(SUM(monto), 0) FROM transacciones WHERE usuarioId = :usuarioId AND tipo = 'GASTO'")
    double obtenerTotalGastos(int usuarioId);

    @Query("SELECT * FROM transacciones WHERE usuarioId = :usuarioId AND tipo = :tipo ORDER BY fecha DESC")
    List<Transaccion> obtenerPorTipo(int usuarioId, String tipo);

    @Query("SELECT * FROM transacciones WHERE categoriaId = :categoriaId ORDER BY fecha DESC")
    List<Transaccion> obtenerPorCategoria(int categoriaId);
}