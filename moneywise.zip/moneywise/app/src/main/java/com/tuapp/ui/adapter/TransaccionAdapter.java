package com.tuapp.ui.adapter;


import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.tuapp.entity.Transaccion;
import com.tuapp.moneywise.R;

import java.util.List;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class TransaccionAdapter extends RecyclerView.Adapter<TransaccionAdapter.TransaccionViewHolder> {

    private List<Transaccion> transacciones;
    private final OnTransaccionClickListener listener;
    private final DecimalFormat formatoMoneda = new DecimalFormat("$#,##0.00");
    private final SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());

    public interface OnTransaccionClickListener {
        void onTransaccionClick(Transaccion transaccion);
        void onTransaccionLongClick(Transaccion transaccion);
    }

    public TransaccionAdapter(List<Transaccion> transacciones, OnTransaccionClickListener listener) {
        this.transacciones = transacciones;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TransaccionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaccion, parent, false);
        return new TransaccionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TransaccionViewHolder holder, int position) {
        Transaccion transaccion = transacciones.get(position);
        holder.bind(transaccion);
    }

    @Override
    public int getItemCount() {
        return transacciones != null ? transacciones.size() : 0;
    }

    public void actualizarLista(List<Transaccion> nuevasTransacciones) {
        this.transacciones = nuevasTransacciones;
        notifyDataSetChanged();
    }

    public class TransaccionViewHolder extends RecyclerView.ViewHolder {

        private final ImageView iconoCategoria;
        private final TextView textDescripcion;
        private final TextView textCategoria;
        private final TextView textFecha;
        private final TextView textMonto;
        private final TextView textCuenta;

        public TransaccionViewHolder(@NonNull View itemView) {
            super(itemView);

            iconoCategoria = itemView.findViewById(R.id.iconoCategoria);
            textDescripcion = itemView.findViewById(R.id.textDescripcion);
            textCategoria = itemView.findViewById(R.id.textCategoria);
            textFecha = itemView.findViewById(R.id.textFecha);
            textMonto = itemView.findViewById(R.id.textMonto);
            textCuenta = itemView.findViewById(R.id.textCuenta);

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onTransaccionClick(transacciones.get(position));
                    }
                }
            });

            itemView.setOnLongClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onTransaccionLongClick(transacciones.get(position));
                        return true;
                    }
                }
                return false;
            });
        }

        public void bind(Transaccion transaccion) {
            // Descripción
            textDescripcion.setText(transaccion.getDescripcion());

            // Categoría
            textCategoria.setText(transaccion.getCategoriaNombre());

            // Fecha
            if (transaccion.getFecha() != null) {
                textFecha.setText(formatoFecha.format(transaccion.getFecha()));
            }

            // Monto - colores diferentes para ingresos y gastos
            textMonto.setText(formatoMoneda.format(transaccion.getMonto()));
            if (transaccion.getTipo().equals("INGRESO")) {
                textMonto.setTextColor(itemView.getContext().getColor(R.color.green_500));
            } else {
                textMonto.setTextColor(itemView.getContext().getColor(R.color.red_500));
            }

            // Cuenta (opcional)
            if (transaccion.getCuentaNombre() != null && !transaccion.getCuentaNombre().isEmpty()) {
                textCuenta.setText(transaccion.getCuentaNombre());
                textCuenta.setVisibility(View.VISIBLE);
            } else {
                textCuenta.setVisibility(View.GONE);
            }

            // Icono basado en categoría
            int iconResId = obtenerIconoCategoria(transaccion.getCategoriaNombre());
            iconoCategoria.setImageResource(iconResId);

            // Color de fondo del icono basado en categoría
            int colorFondo = obtenerColorCategoria(transaccion.getCategoriaNombre());
            iconoCategoria.setBackgroundColor(colorFondo);
        }

        private int obtenerIconoCategoria(String categoria) {
            // Mapeo de categorías a iconos - puedes expandir esto
            if (categoria == null) return R.drawable.ic_baseline_attach_money_24;

            switch (categoria.toLowerCase()) {
                case "comida":
                case "alimentación":
                    return R.drawable.ic_baseline_restaurant_24;
                case "transporte":
                    return R.drawable.ic_baseline_directions_car_24;
                case "entretenimiento":
                    return R.drawable.ic_baseline_movie_24;
                case "salud":
                    return R.drawable.ic_baseline_local_hospital_24;
                case "educación":
                    return R.drawable.ic_baseline_school_24;
                case "ropa":
                    return R.drawable.ic_baseline_checkroom_24;
                case "hogar":
                    return R.drawable.ic_baseline_home_24;
                default:
                    return R.drawable.ic_baseline_attach_money_24;
            }
        }

        private int obtenerColorCategoria(String categoria) {
            // Mapeo de categorías a colores
            if (categoria == null) return Color.parseColor("#FF9800");

            switch (categoria.toLowerCase()) {
                case "comida": return Color.parseColor("#4CAF50");
                case "transporte": return Color.parseColor("#2196F3");
                case "entretenimiento": return Color.parseColor("#9C27B0");
                case "salud": return Color.parseColor("#F44336");
                case "educación": return Color.parseColor("#FF9800");
                case "ropa": return Color.parseColor("#E91E63");
                case "hogar": return Color.parseColor("#795548");
                default: return Color.parseColor("#607D8B");
            }
        }
    }
}