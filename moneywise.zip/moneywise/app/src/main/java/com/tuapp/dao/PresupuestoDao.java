package com.tuapp.dao;
import androidx.room.*;
import com.tuapp.entity.Presupuesto;

import java.util.List;

@Dao
public interface PresupuestoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertar(Presupuesto presupuesto);

    @Update
    void actualizar(Presupuesto presupuesto);

    @Delete
    void eliminar(Presupuesto presupuesto);

    @Query("SELECT * FROM presupuestos WHERE id = :id")
    Presupuesto obtenerPorId(int id);

    @Query("SELECT * FROM presupuestos WHERE usuarioId = :usuarioId")
    List<Presupuesto> obtenerPorUsuario(int usuarioId);

    @Query("SELECT * FROM presupuestos WHERE usuarioId = :usuarioId AND mes = :mes")
    List<Presupuesto> obtenerPorUsuarioYMes(int usuarioId, String mes);

    @Query("SELECT * FROM presupuestos WHERE usuarioId = :usuarioId AND nombre LIKE '%' || :nombre || '%'")
    List<Presupuesto> buscarPorNombre(int usuarioId, String nombre);

    @Query("UPDATE presupuestos SET montoGastado = montoGastado + :monto WHERE id = :presupuestoId")
    void actualizarMontoGastado(int presupuestoId, double monto);

    @Query("UPDATE presupuestos SET montoGastado = montoGastado - :monto WHERE id = :presupuestoId")
    void reducirMontoGastado(int presupuestoId, double monto);

    @Query("SELECT SUM(montoTotal) FROM presupuestos WHERE usuarioId = :usuarioId AND mes = :mes")
    Double obtenerTotalPresupuestado(int usuarioId, String mes);

    @Query("SELECT SUM(montoGastado) FROM presupuestos WHERE usuarioId = :usuarioId AND mes = :mes")
    Double obtenerTotalGastado(int usuarioId, String mes);

    @Query("DELETE FROM presupuestos WHERE usuarioId = :usuarioId")
    void eliminarTodosPorUsuario(int usuarioId);

    @Query("SELECT * FROM presupuestos WHERE usuarioId = :usuarioId AND montoGastado > montoTotal * 0.8")
    List<Presupuesto> obtenerPresupuestosCercaDelLimite(int usuarioId);

    @Query("SELECT * FROM presupuestos WHERE usuarioId = :usuarioId AND montoGastado > montoTotal")
    List<Presupuesto> obtenerPresupuestosExcedidos(int usuarioId);
}
