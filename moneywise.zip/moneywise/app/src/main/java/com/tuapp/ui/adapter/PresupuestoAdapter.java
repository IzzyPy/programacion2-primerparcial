package com.tuapp.ui.adapter;


import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.tuapp.entity.Presupuesto;
import com.tuapp.moneywise.R;

import java.text.DecimalFormat;
import java.util.List;

public class PresupuestoAdapter extends RecyclerView.Adapter<PresupuestoAdapter.PresupuestoViewHolder> {

    private List<Presupuesto> presupuestos;
    private final OnPresupuestoClickListener listener;
    private final DecimalFormat formatoMoneda = new DecimalFormat("$#,##0.00");

    public interface OnPresupuestoClickListener {
        void onPresupuestoClick(Presupuesto presupuesto);
        void onPresupuestoLongClick(Presupuesto presupuesto);
    }

    public PresupuestoAdapter(List<Presupuesto> presupuestos, OnPresupuestoClickListener listener) {
        this.presupuestos = presupuestos;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PresupuestoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_presupuesto, parent, false);
        return new PresupuestoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PresupuestoViewHolder holder, int position) {
        Presupuesto presupuesto = presupuestos.get(position);
        holder.bind(presupuesto);
    }

    @Override
    public int getItemCount() {
        return presupuestos != null ? presupuestos.size() : 0;
    }

    public void actualizarLista(List<Presupuesto> nuevosPresupuestos) {
        this.presupuestos = nuevosPresupuestos;
        notifyDataSetChanged();
    }

    public class PresupuestoViewHolder extends RecyclerView.ViewHolder {

        private final TextView textCategoria;
        private final TextView textMonto;
        private final TextView textGastado;
        private final TextView textPorcentaje;
        private final ProgressBar progressBar;

        public PresupuestoViewHolder(@NonNull View itemView) {
            super(itemView);

            textCategoria = itemView.findViewById(R.id.textCategoria);
            textMonto = itemView.findViewById(R.id.textMonto);
            textGastado = itemView.findViewById(R.id.textGastado);
            textPorcentaje = itemView.findViewById(R.id.textPorcentaje);
            progressBar = itemView.findViewById(R.id.progressBar);

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onPresupuestoClick(presupuestos.get(position));
                    }
                }
            });

            itemView.setOnLongClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onPresupuestoLongClick(presupuestos.get(position));
                        return true;
                    }
                }
                return false;
            });
        }

        public void bind(Presupuesto presupuesto) {
            // Nombre de la categoría (necesitarás agregarlo a la entidad Presupuesto)
            textCategoria.setText("Presupuesto"); // Cambiar cuando tengas el nombre

            // Monto del presupuesto
            textMonto.setText(formatoMoneda.format(presupuesto.getMonto()));

            // Gastos actuales (por ahora en 0, necesitarás calcularlo)
            double gastado = 0.0; // TODO: calcular desde transacciones
            textGastado.setText("Gastado: " + formatoMoneda.format(gastado));

            // Porcentaje y progress bar
            int porcentaje = 0;
            if (presupuesto.getMonto() > 0) {
                porcentaje = (int) ((gastado / presupuesto.getMonto()) * 100);
            }
            textPorcentaje.setText(porcentaje + "%");
            progressBar.setProgress(porcentaje);

            // Color del progress bar según el porcentaje
            if (porcentaje < 70) {
                progressBar.getProgressDrawable().setColorFilter(
                        itemView.getContext().getColor(R.color.green_500),
                        android.graphics.PorterDuff.Mode.SRC_IN
                );
            } else if (porcentaje < 90) {
                progressBar.getProgressDrawable().setColorFilter(
                        Color.parseColor("#FFA500"), // Naranja
                        android.graphics.PorterDuff.Mode.SRC_IN
                );
            } else {
                progressBar.getProgressDrawable().setColorFilter(
                        itemView.getContext().getColor(R.color.red_500),
                        android.graphics.PorterDuff.Mode.SRC_IN
                );
            }
        }
    }
}