package com.tuapp.entity;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
import androidx.room.Index;

@Entity(
        tableName = "presupuestos",
        foreignKeys = @ForeignKey(
                entity = Usuario.class,
                parentColumns = "id",
                childColumns = "usuarioId",
                onDelete = ForeignKey.CASCADE
        ),
        indices = {@Index("usuarioId")}
)
public class Presupuesto {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String nombre;
    private double montoTotal;
    private double montoGastado;
    private String mes;
    private int usuarioId;

    // ✅ AGREGAR CONSTRUCTOR VACÍO (NECESARIO PARA ROOM)
    public Presupuesto() {
    }

    public Presupuesto(String nombre, double montoTotal, String mes, int usuarioId) {
        this.nombre = nombre;
        this.montoTotal = montoTotal;
        this.montoGastado = 0;
        this.mes = mes;
        this.usuarioId = usuarioId;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public double getMontoTotal() { return montoTotal; }
    public void setMontoTotal(double montoTotal) { this.montoTotal = montoTotal; }
    public double getMontoGastado() { return montoGastado; }
    public void setMontoGastado(double montoGastado) { this.montoGastado = montoGastado; }
    public String getMes() { return mes; }
    public void setMes(String mes) { this.mes = mes; }
    public int getUsuarioId() { return usuarioId; }
    public void setUsuarioId(int usuarioId) { this.usuarioId = usuarioId; }

    // ✅ AGREGAR MÉTODO getMonto() QUE FALTA
    public double getMonto() {
        return this.montoTotal;
    }
}