package com.tuapp.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.Ignore;
import androidx.room.TypeConverters;

import com.tuapp.data.Converters;

import java.util.Date;

@Entity(
        tableName = "transacciones",
        foreignKeys = {
                @ForeignKey(
                        entity = Usuario.class,
                        parentColumns = "id",
                        childColumns = "usuarioId",
                        onDelete = ForeignKey.CASCADE
                ),
                @ForeignKey(
                        entity = Categoria.class,
                        parentColumns = "id",
                        childColumns = "categoriaId",
                        onDelete = ForeignKey.SET_NULL
                ),
                @ForeignKey(
                        entity = Cuenta.class,
                        parentColumns = "id",
                        childColumns = "cuentaId",
                        onDelete = ForeignKey.SET_NULL
                )
        },
        indices = {
                @Index("usuarioId"),
                @Index("categoriaId"),
                @Index("cuentaId")
        }
)
@TypeConverters({Converters.class})
public class Transaccion {

    @PrimaryKey(autoGenerate = true)
    private Long id;

    private Long usuarioId;
    private String descripcion;
    private Double monto;
    private String tipo; // "INGRESO" o "GASTO"
    private Date fecha;
    private Long categoriaId;
    private Long cuentaId;

    // Campos que NO se guardan en la base de datos
    @Ignore
    private String categoriaNombre;

    @Ignore
    private String cuentaNombre;

    // Constructor vacío requerido por Room
    public Transaccion() {
    }

    // Constructor con parámetros (sin los campos @Ignore)
    public Transaccion(Long usuarioId, String descripcion, Double monto, String tipo,
                       Date fecha, Long categoriaId, Long cuentaId) {
        this.usuarioId = usuarioId;
        this.descripcion = descripcion;
        this.monto = monto;
        this.tipo = tipo;
        this.fecha = fecha;
        this.categoriaId = categoriaId;
        this.cuentaId = cuentaId;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Long getCategoriaId() {
        return categoriaId;
    }

    public void setCategoriaId(Long categoriaId) {
        this.categoriaId = categoriaId;
    }

    public Long getCuentaId() {
        return cuentaId;
    }

    public void setCuentaId(Long cuentaId) {
        this.cuentaId = cuentaId;
    }

    // Getters y Setters para campos @Ignore
    public String getCategoriaNombre() {
        return categoriaNombre;
    }

    public void setCategoriaNombre(String categoriaNombre) {
        this.categoriaNombre = categoriaNombre;
    }

    public String getCuentaNombre() {
        return cuentaNombre;
    }

    public void setCuentaNombre(String cuentaNombre) {
        this.cuentaNombre = cuentaNombre;
    }
}