package com.tuapp.ui.adapter.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.tuapp.data.AppDatabase;
import com.tuapp.entity.Presupuesto;
import com.tuapp.moneywise.databinding.FragmentPresupuestosBinding;
import com.tuapp.ui.adapter.PresupuestoAdapter;
import java.util.ArrayList;
import java.util.List;

public class PresupuestosFragment extends Fragment {

    private FragmentPresupuestosBinding binding;
    private AppDatabase db;
    private PresupuestoAdapter adapter;
    private int usuarioId = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentPresupuestosBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = AppDatabase.getInstance(requireContext());

        configurarRecyclerView();
        cargarPresupuestos();

        binding.fabAgregarPresupuesto.setOnClickListener(v -> mostrarDialogoAgregar());
    }

    private void configurarRecyclerView() {
        binding.recyclerViewPresupuestos.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new PresupuestoAdapter(new ArrayList<>(), new PresupuestoAdapter.OnPresupuestoClickListener() {
            @Override
            public void onPresupuestoClick(Presupuesto presupuesto) {
                // Navegar a detalles
            }

            @Override
            public void onPresupuestoLongClick(Presupuesto presupuesto) {
                // Mostrar opciones (editar/eliminar)
            }
        });
        binding.recyclerViewPresupuestos.setAdapter(adapter);
    }

    private void cargarPresupuestos() {
        new Thread(() -> {
            List<Presupuesto> presupuestos = db.presupuestoDao().obtenerPorUsuario(usuarioId);

            if (getActivity() != null && isAdded()) {
                getActivity().runOnUiThread(() -> {
                    if (adapter != null && binding != null) {
                        adapter.actualizarLista(presupuestos);
                    }
                });
            }
        }).start();
    }

    private void mostrarDialogoAgregar() {
        // Implementar diálogo para agregar presupuesto
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}