package com.tuapp.dao;

import androidx.room.*;
import com.tuapp.entity.Usuario;

import java.util.List;

@Dao
public interface UsuarioDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertar(Usuario usuario);

    @Update
    void actualizar(Usuario usuario);

    @Delete
    void eliminar(Usuario usuario);

    @Query("SELECT * FROM usuarios WHERE id = :id")
    Usuario obtenerPorId(int id);

    @Query("SELECT * FROM usuarios WHERE email = :email")
    Usuario obtenerPorEmail(String email);

    @Query("SELECT * FROM usuarios WHERE email = :email AND password = :password")
    Usuario login(String email, String password);

    @Query("SELECT COUNT(*) FROM usuarios WHERE email = :email")
    int existeEmail(String email);

    @Query("UPDATE usuarios SET nombre = :nombre, email = :email WHERE id = :id")
    void actualizarPerfil(int id, String nombre, String email);

    @Query("UPDATE usuarios SET password = :nuevaPassword WHERE id = :id AND password = :passwordActual")
    int cambiarPassword(int id, String passwordActual, String nuevaPassword);

    @Query("SELECT * FROM usuarios")
    List<Usuario> obtenerTodos();
}