package com.tuapp.ui.adapter;


import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.tuapp.entity.Cuenta;
import com.tuapp.moneywise.databinding.ItemCuentaBinding;
import java.util.List;
import java.util.Locale;

public class CuentaAdapter extends RecyclerView.Adapter<CuentaAdapter.CuentaViewHolder> {

    private List<Cuenta> cuentas;
    private OnCuentaClickListener listener;

    public interface OnCuentaClickListener {
        void onCuentaClick(Cuenta cuenta);
    }

    public CuentaAdapter(List<Cuenta> cuentas, OnCuentaClickListener listener) {
        this.cuentas = cuentas;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CuentaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemCuentaBinding binding = ItemCuentaBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new CuentaViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CuentaViewHolder holder, int position) {
        holder.bind(cuentas.get(position));
    }

    @Override
    public int getItemCount() {
        return cuentas.size();
    }

    class CuentaViewHolder extends RecyclerView.ViewHolder {
        private ItemCuentaBinding binding;

        CuentaViewHolder(ItemCuentaBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(Cuenta cuenta) {
            binding.tvNombreCuenta.setText(cuenta.getNombre());
            binding.tvSaldoCuenta.setText(String.format(Locale.getDefault(),
                    "$%.2f", cuenta.getSaldoActual()));

            binding.getRoot().setOnClickListener(v -> {
                if (listener != null) {
                    listener.onCuentaClick(cuenta);
                }
            });
        }
    }

    public void actualizarLista(List<Cuenta> nuevasCuentas) {
        this.cuentas = nuevasCuentas;
        notifyDataSetChanged();
    }
}